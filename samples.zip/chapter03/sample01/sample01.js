"use strict";
var message = 'EcmaScriptを勉強中です';
console.log(message);

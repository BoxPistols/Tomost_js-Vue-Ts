let message = 'EcmaScriptを勉強中です';

console.log(message);
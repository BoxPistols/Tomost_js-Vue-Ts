let myname: any = 'たにぐちまこと';
let height: string | number = 169;

myname = 10;
height = 'わからない';
"use strict";
var sum = function (a, b) {
    return a * b;
};
var answer = sum(5, 2);
console.log(answer);

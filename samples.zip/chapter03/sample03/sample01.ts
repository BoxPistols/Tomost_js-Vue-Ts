const sum = (a: number, b: number): number => {
    return a * b;
}

let answer: number = sum(5, 2);
console.log(answer);
let tel: number | string;

tel = 1234567;
tel = '123-4567-8900';
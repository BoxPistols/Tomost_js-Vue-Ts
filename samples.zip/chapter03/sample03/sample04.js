"use strict";
var myname = 'たにぐちまこと';
var height = 169;
myname = 10;
height = 'わからない';

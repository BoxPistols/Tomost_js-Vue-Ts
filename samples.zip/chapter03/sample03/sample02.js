"use strict";
var addMark = function (message) {
    return ('■' + message);
};
console.log(addMark('文字列を指定します'));
console.log(addMark(10));

"use strict";
var color;
color = '赤';
// color = '黒';

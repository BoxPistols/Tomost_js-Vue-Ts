"use strict";
var Fruit = /** @class */ (function () {
    function Fruit() {
        this.name = '';
        this.price = 0;
    }
    return Fruit;
}());
var Snack = /** @class */ (function () {
    function Snack() {
        this.name = '';
        this.price = 0;
    }
    return Snack;
}());

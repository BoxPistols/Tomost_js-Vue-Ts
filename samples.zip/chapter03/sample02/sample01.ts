let x: number = 1;
let y: number = 2;

//x = '文字列を代入します';

console.log(x * y);
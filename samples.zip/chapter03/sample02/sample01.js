"use strict";
var x = 1;
var y = 2;
//x = '文字列を代入します';
console.log(x * y);
